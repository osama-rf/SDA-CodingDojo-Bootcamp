print("Hello World!")

my_name = "osama"

print("Hello " + my_name)

num = 41

print("Hello " + str(num))

num = 41

print("Hello " + str(num))

food_1 = "pizza"
food_2 = "burger"

print("I love to eat this foods " + food_1 + " and "+ food_2)

print(f"I love to eat this foods {food_1} and {food_2}")







