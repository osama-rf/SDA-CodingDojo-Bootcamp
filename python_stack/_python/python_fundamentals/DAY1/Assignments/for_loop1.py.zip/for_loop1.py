# for i in range(0, 151):
#     print(i)


# for x in range(5, 1001, 5):
#     print(x)


# for j in range(0, 101):
#     if j % 5 == 0:
#         print("Coding")
#     elif j % 10 == 0:
#         print("Coding Dojo")
#     else:
#         print(j)

# sum = 0
# for k in range(0, 500000):
#     sum +=k 
# print(sum)

# for s in range(2018, 0, -4):
#     print(s)

lowNum = 2
highNum = 9
mult = 3

for l in range(lowNum, highNum+1, 1):
    if l % mult == 0:
        print(l)

    






