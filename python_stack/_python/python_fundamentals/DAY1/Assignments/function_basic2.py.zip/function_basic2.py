# arr = []
# def countdown(num):
#     for i in range(num, -1, -1):
#         arr.append(i)
#     return(arr)

# print(countdown(10))

# ======================================= #

# def print_and_return(list):
#     print(list[0])
#     return list[1]

# print(print_and_return([4,10]))

# ======================================= #

# def first_length(num):
#     print(num[0])
#     return len(num)

# print(first_length([10,2,5,91,1]))

# ======================================= #


# def greater_second(num):
#     if len(num) < 2:
#         return False
#     list1 = []

#     for i in num:
#         if i > num [1]:
#             list1.append(i)
#         print(len(list1))
#         return list1


# print(greater_second([5,2,3,2,1,4]))
# print(greater_second([5,2]))
# print(greater_second([1]))

# ======================================= #

def length_value(size, value):
    list= []
    for i in range (size):
        list.append(value)
    return list


print(length_value(5,7))