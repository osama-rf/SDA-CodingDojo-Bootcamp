from django.apps import AppConfig


class SurveysappConfig(AppConfig):
    name = 'surveysApp'
