from django.apps import AppConfig


class DjangoappZeroConfig(AppConfig):
    name = 'djangoApp_zero'
