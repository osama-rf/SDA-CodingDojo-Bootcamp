from django.shortcuts import HttpResponse

def index(request):
    return HttpResponse('Placeholder to display all the list of users')

