from django.apps import AppConfig


class UsersappConfig(AppConfig):
    name = 'usersApp'
