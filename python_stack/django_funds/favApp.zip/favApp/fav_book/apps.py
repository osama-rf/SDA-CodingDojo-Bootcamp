from django.apps import AppConfig


class FavBookConfig(AppConfig):
    name = 'fav_book'
