from django.apps import AppConfig


class DojosruveyappConfig(AppConfig):
    name = 'dojoSruveyApp'
