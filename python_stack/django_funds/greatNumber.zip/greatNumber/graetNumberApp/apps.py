from django.apps import AppConfig


class GraetnumberappConfig(AppConfig):
    name = 'graetNumberApp'
