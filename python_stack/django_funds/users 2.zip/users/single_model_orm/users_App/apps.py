from django.apps import AppConfig


class SingleModelOrmappConfig(AppConfig):
    name = 'single_model_ormApp'
