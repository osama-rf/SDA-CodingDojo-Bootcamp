from django.apps import AppConfig


class TimedisplayappConfig(AppConfig):
    name = 'timeDisplayApp'
