from django.apps import AppConfig


class SemirestfultvshowsappConfig(AppConfig):
    name = 'SemiRestfulTVShowsApp'
