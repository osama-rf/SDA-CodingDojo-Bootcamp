from unicodedata import name
from django.shortcuts import render, redirect
from .models import League, Team, Player

from . import team_maker

def index(request):
	context = {
		"leagues": League.objects.all(),
		"teams": Team.objects.all(),
		"players": Player.objects.all(),
		"baseball_league": League.objects.filter(sport = 'Baseball'),
		"womens_league": League.objects.filter(name__contains = 'Womens'),
		"hockey_league": League.objects.filter(sport__contains = 'hockey'),
		"without_football": League.objects.exclude(sport= 'Football'),
		"conferences": League.objects.filter(name__contains = 'Conference'),
		"atlantic_region": League.objects.filter(name__contains = 'Atlantic'),
		"dallas_teams": Team.objects.filter(location = 'Dallas'),
		"Raptors": Team.objects.filter(team_name = 'Raptors'),
		"City_teams": Team.objects.filter(location__contains = 'City'),
		"t_teams": Team.objects.filter(team_name__contains = 'T'),
		"alpha_order": Team.objects.all().order_by('location'),
		"order_name": Team.objects.all().order_by('-team_name'),
		"cooper_name": Player.objects.filter(last_name = "Cooper"),
		"joshua_name": Player.objects.filter(first_name = "Joshua"),
		"exept_joshua": Player.objects.filter(last_name = "Cooper").exclude(first_name = 'Joshua'),
		"alex_wyatt": Player.objects.filter(first_name__in=['Alexander', 'Wyatt'])

	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")