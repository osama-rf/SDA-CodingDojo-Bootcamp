from django.apps import AppConfig


class BookAuthorsappConfig(AppConfig):
    name = 'book_authorsApp'
