console.log("page loaded...");

function playVideo(vid) {
    vid.play();
}

function stopVideo(vid) {
    vid.pause();
}