for (var i=0; i<=6 ; i++){
    if (i % 2 == 0){
        console.log("take a cake")
    }
    if(i == 6)break;
}